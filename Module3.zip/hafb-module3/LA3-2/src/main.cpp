#include <iostream>
#include "counter.h"
using namespace std;

// Main Function
int main() 
{
  
  return 0;
}
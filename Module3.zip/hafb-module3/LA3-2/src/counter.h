// increment counter variable with ++ operator
// uses unnamed temporary object

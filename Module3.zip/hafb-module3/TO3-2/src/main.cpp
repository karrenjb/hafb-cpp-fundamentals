#include <iostream>
#include "coordinates.h"
using namespace std;

// Main Function
int main() 
{

  return 0;
}
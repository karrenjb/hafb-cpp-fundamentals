# HAFB Module 3: Classes Part II
In this module we continue our discussion on classes. 

## Learning Objectives
At the end of this module students will have
- Implement a nested class
- Utilize the friend specifier to access private and protected members
- Use constructors, copy constructors, assignment operators, and destructors
- Overload operators

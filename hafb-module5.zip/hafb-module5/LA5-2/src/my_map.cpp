#include <iostream>
#include <map>
#include <string>

int main()
{

    return 0;
}
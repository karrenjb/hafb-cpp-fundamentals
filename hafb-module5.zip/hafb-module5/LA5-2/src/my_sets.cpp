#include <iostream>
#include <set>

int main()
{

}
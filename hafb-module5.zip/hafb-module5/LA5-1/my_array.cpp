#include <iostream>
using namespace std;
#include <array>
#include <algorithm>

// Local Prototypes
void fun(int const& value); 


int main()
{
    return 0;
}

// Local function definitions
void fun(int const& value) 
{
    std::cout << value << "\n";
}
#include <iostream>
#include <vector>
#include <algorithm>
using namespace std;

int main()
{

    return 0;
}
#include <iostream>
using namespace std;

// Local Prototypes

int main()
{
   return 0;
}

#include <iostream>
#include <algorithm>
#include <vector>
 
int main()
{
    return 0;
}
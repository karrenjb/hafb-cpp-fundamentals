#include <iostream>
#include <random>
#include <vector>
#include <algorithm>
#include <iterator>

int main()
{
    
    return 0;
}

#include <iostream>

// Main Function
int main()
{
  // Lambda syntax: 
  // [captured variables] (arguments){ body }
  

  return 0;
}